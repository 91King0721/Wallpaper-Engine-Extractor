@echo off
chcp 65001 >nul
echo Building standalone .exe with PyInstaller...
echo.
pip install pyinstaller
pyinstaller --windowed --onefile --name "WallpaperEngineExtractor" --icon "icon.ico" --add-data "extractor;extractor" --hidden-import "extractor.pkg" --hidden-import "extractor.tex" --hidden-import "extractor.utils" --hidden-import "tkinterdnd2" --collect-all "tkinterdnd2" gui.py
echo.
if exist "dist\WallpaperEngineExtractor.exe" (
    echo Success! dist\WallpaperEngineExtractor.exe
) else (
    echo Build failed.
)
pause
