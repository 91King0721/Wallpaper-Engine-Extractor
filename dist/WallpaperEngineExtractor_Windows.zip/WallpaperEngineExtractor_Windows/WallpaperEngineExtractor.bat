@echo off
chcp 65001 >nul
title Wallpaper Engine Media Extractor

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    msg %username% "Python 3 is required! Download: https://www.python.org/downloads/"
    exit /b 1
)

:: Check tkinterdnd2
python -c "import tkinterdnd2" >nul 2>&1
if errorlevel 1 (
    msg %username% "Installing tkinterdnd2 for drag-and-drop support..."
    pip install tkinterdnd2
)

cd /d "%~dp0"
python gui.py
pause
